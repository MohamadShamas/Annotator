function stat = memprofile(varargin)

% MEMPROFILE this is a dummy placeholder

if nargout
  stat.mem = [0 0 0 0];
end
